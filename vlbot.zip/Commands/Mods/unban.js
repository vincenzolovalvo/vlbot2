const { mku } = require("../../Database/dataschema.js");

module.exports = {
  name: "unban",
  alias: ["unban"],
  desc: "Unban a member",
  category: "core",
  usage: "unban @user",
  react: "🎀",
  start: async (
    Miku,
    m,
    {
      text,
      prefix,
      isBotAdmin,
      isAdmin,
      mentionByTag,
      pushName,
      isCreator,
      modStatus,
    }
  ) => {
    if (modStatus == "false" && !isCreator)
      return Miku.sendMessage(
        m.from,
        { text: "Scusa, solo il *Creatore* e i *Moderatori* Possono usare questo comando !" },
        { quoted: m }
      );

    if (!text && !m.quoted) {
      return Miku.sendMessage(
        m.from,
        { text: `Tagga un user da *Sbannare*!` },
        { quoted: m }
      );
    } else if (m.quoted) {
      var mentionedUser = m.quoted.sender;
    } else {
      var mentionedUser = mentionByTag[0];
    }

    let userId = (await mentionedUser) || m.msg.contextInfo.participant;
    try {
      mku
        .findOne({ id: userId })
        .then(async (user) => {
          if (!user) {
            return Miku.sendMessage(
              m.from,
              {
                text: `@${mentionedUser.split("@")[0]} non è *Bannato* !`,
                mentions: [mentionedUser],
              },
              { quoted: m }
            );
          } else {
            if (user.ban == "false")
              return Miku.sendMessage(
                m.from,
                {
                  text: `@${mentionedUser.split("@")[0]} non è *Bannato* !`,
                  mentions: [mentionedUser],
                },
                { quoted: m }
              );
            await mku.findOneAndUpdate(
              { id: userId },
              { ban: false },
              { new: true }
            );
            return Miku.sendMessage(
              m.from,
              {
                text: `@${
                  mentionedUser.split("@")[0]
                } è stato *Sbannato* Correttamente! da *${pushName}*`,
                mentions: [mentionedUser],
              },
              { quoted: m }
            );
          }
        })
        .catch((error) => {
          console.log(error);
          return Miku.sendMessage(
            m.from,
            { text: `Errore durante lo sban.` },
            { quoted: m }
          );
        });
    } catch (err) {
      console.log(err);
      return Miku.sendMessage(
        m.from,
        { text: `Errore durante lo sban.` },
        { quoted: m }
      );
    }
  },
};
