const { mku } = require("../../Database/dataschema.js");

module.exports = {
  name: "ban",
  alias: ["banuser"],
  desc: "Ban a member",
  category: "core",
  usage: "ban @user",
  react: "🎀",
  start: async (
    Miku,
    m,
    {
      text,
      prefix,
      isBotAdmin,
      isAdmin,
      mentionByTag,
      metadata,
      pushName,
      isCreator,
      args,
      modStatus,
    }
  ) => {
    if (modStatus == "false" && !isCreator)
      return Miku.sendMessage(
        m.from,
        { text: "Scusa, solo il *Creatore* e i *Moderatori* Possono usare questo comando !" },
        { quoted: m }
      );

    //var TaggedUser = mentionByTag[0];

    if (!text && !m.quoted) {
      return Miku.sendMessage(
        m.from,
        { text: `Tagga un user da *Bannare*!` },
        { quoted: m }
      );
    }else if (m.quoted) {
      var mentionedUser = m.quoted.sender;
    } else {
      var mentionedUser = mentionByTag[0];
    }
    
    let GroupName = metadata.subject;
    let banreason = args.join(" ");

    if (m.quoted && !args.join(" ")) {
      banreason = "Nessuna motivazione";
    }

    if (m.quoted && args.join(" ")) {
      banreason = text;
    }

    if (banreason.includes("@")) {
      banreason = args.join(" ");
    }

    if (banreason == undefined) {
      banreason = "Nessuna motivazione";
    }
    var ownerlist = global.owner;

    let userId = (await mentionedUser) || m.msg.contextInfo.participant;
    try {
      mku
        .findOne({ id: userId })
        .then(async (user) => {
          if (!user) {
            await mku.create({
              id: userId,
              ban: true,
              reason: banreason,
              gcname: GroupName,
            });
            return Miku.sendMessage(
              m.from,
              {
                text: `@${
                  mentionedUser.split("@")[0]
                } è stato *Bannato* correttamente da *${pushName}*\n\n *motivazione*: ${banreason}`,
                mentions: [mentionedUser],
              },
              { quoted: m }
            );
          } else {
            if (
              modStatus == "true" ||
              ownerlist.includes(`${mentionedUser.split("@")[0]}`)
            )
              return Miku.sendMessage(
                m.from,
                {
                  text: `@${
                    mentionedUser.split("@")[0]
                  } è un *Moderatore* non può essere bannato !`,
                  mentions: [mentionedUser],
                },
                { quoted: m }
              );
            if (user.ban == "true")
              return Miku.sendMessage(
                m.from,
                {
                  text: `@${mentionedUser.split("@")[0]} è già *Bannato* !`,
                  mentions: [mentionedUser],
                },
                { quoted: m }
              );
            await mku.findOneAndUpdate(
              { id: userId },
              { $set: { ban: true, reason: banreason, gcname: GroupName } },
              { new: true }
            );
            return Miku.sendMessage(
              m.from,
              {
                text: `@${
                  mentionedUser.split("@")[0]
                } è stato *Bannato* correttamente da *${pushName}*\n\n *Motivazione*: ${banreason}`,
                mentions: [mentionedUser],
              },
              { quoted: m }
            );
          }
        })
        .catch((error) => {
          console.log(error);
          return Miku.sendMessage(
            m.from,
            { text: `Errore durante il ban.` },
            { quoted: m }
          );
        });
    } catch (err) {
      console.log(err);
      return Miku.sendMessage(
        m.from,
        { text: `Errore durante il ban.` },
        { quoted: m }
      );
    }
  },
};
