let { TelegraPh } = require("../../lib/uploader");
const fs = require("fs");
const util = require("util");

module.exports = {
  name: "tourl",
  alias: ["makeurl"],
  desc: "To make a url from image/video/gif",
  category: "Utilities",
  usage: "sticker <reply to image>",
  react: "🍁",
  start: async (Miku, m, { quoted, mime }) => {
    let media = await Miku.downloadAndSaveMediaMessage(quoted);
    if (/image/.test(mime)) {
      let anu = await TelegraPh(media);
      m.reply(`*URL foto:* \n\n${util.format(anu)}\n`);
    } else if (/video/.test(mime)) {
      if (media.size > 5 * 1024 * 1024) {
        m.reply(`*La grandezza del video è troppo grande*\n\n*Massimo:* 5MB`);
      }
      let anu = await TelegraPh(media);
      m.reply(`*URL video:* \n\n${util.format(anu)}\n`);
    } else {
      m.reply(`Rispondi ad una immagine!`);
    }
    await fs.unlinkSync(media);
  },
};
