const { Anime } = require("@shineiichijo/marika");
const client = new Anime();

module.exports = {
  name: "anime",
  alias: ["animesearch"],
  desc: "To get an anime search result",
  category: "Search",
  usage: `anime <search term>`,
  react: "🍁",
  start: async (Miku, m, { text, prefix, args }) => {
    if (!args[0])
      return Miku.sendMessage(
        m.from,
        { text: `Dammi un titolo di un anime!` },
        { quoted: m }
      );

    var AnimesearchTerm = args.join(" ");
    let anime = await client.searchAnime(AnimesearchTerm);

    let result = anime.data[0];
    let details = `       *『  Ricerca Anime Avanzata  』*\n\n\n*🎀 Titolo anime:* ${result.title}\n`;
    details += `\n*🎋 Formato:* ${result.type}\n`;
    details += `*📈 Stato:* ${result.status
      .toUpperCase()
      .replace(/\_/g, " ")}\n`;
    details += `*🍥 Episodi totali:* ${result.episodes}\n`;
    details += `*🎈 Durata:* ${result.duration}\n`;
    details += `*🧧 Genere:*\n`;
    for (let i = 0; i < result.genres.length; i++) {
      details += `\t\t\t\t\t\t\t\t${result.genres[i].name}\n`;
    }
    details += `\n*✨ Basato su:* ${result.source.toUpperCase()}\n`;
    details += `*📍 Studios:*\n`;
    for (let i = 0; i < result.studios.length; i++) {
      details += `\t\t\t\t\t\t\t\t${result.studios[i].name}\n`;
    }
    details += `*🎴 Produttori:*\n`;
    for (let i = 0; i < result.producers.length; i++) {
      details += `\t\t\t\t\t\t\t\t\t\t${result.producers[i].name}\n`;
    }
    details += `\n*🎐 Popolatità:* ${result.popularity}\n`;
    details += `*🎏 apprezzamento:* ${result.favorites}\n`;
    details += `*🎇 Voto della critica:* ${result.rating}\n`;
    details += `*🏅 Rank:* ${result.rank}\n\n`;
    details += `\n*🌐 Link:* ${result.url}\n\n`;

    await Miku.sendMessage(
      m.from,
      { image: { url: result.images.jpg.large_image_url }, caption: details },
      { quoted: m }
    );
  },
};
