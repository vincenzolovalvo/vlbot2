<h1 align="center">🎀 RPG Usage Rules 🎀
</h1>

<br>

- You are not allowed to manipulate the RPG system.
- You are not allowed to use the RPG system for your own benefit/show off.
- You are not allowed to change the public database added for RPG.

<br>

### Note:
#### RPG is a game and you should play fare and without cheating.
#### If you break these rules you will not get any support from us.