module.exports = {
    name: "palla8",
    alias: ["palla8"],
    desc: "Risponde ad una tua domanda in modo casuale.",
    react: "🎱",
    category: "Core",
    start: async(Miku, m,{pushName,prefix}) => {
        const palla8 = ["È certo", "È decisamente così", "Senza dubbio", "Sì, sicuramente", "Può contarci", "Per come la vedo io, sì", "Molto probabilmente", "Prospettive buone", "Sì", "I segnali indicano sì", "mi sa di no", "ovvio", "Meglio non dirtelo ora", "no", "si", "Non contarci", "La mia risposta è no", "Le mie fonti dicono di no", "Le prospettive non sono buone", "Molto dubbioso"];
const welcomeMessage = palla8[Math.floor(Math.random() * palla8.length)];
        await Miku.sendMessage(m.from,        {
          video: { url: "https://media.tenor.com/Hy5q1VKkNloAAAAC/number8-ball.mp4" },
          caption: `*${welcomeMessage}*\n`,
          gifPlayback: true,
        },{quoted:m})
    }
}