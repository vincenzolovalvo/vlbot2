module.exports = {
    name: "bestemmia",
    alias: ["best"],
    desc: "Lancia una bestemmia per te.",
    react: "🧣",
    category: "Core",
    start: async(Miku, m,{pushName,prefix}) => {
        const bestemmie = ["DIO CANCEROGENO", "DIO CANCHEROSO", "DIO CANE", "DIO CANE BASTARDINO", "DIO CANE DA CORSA", "DIO CANE DA TARTUFO", "DIO CANE LUPO", "DIO CANGURO", "DIO CANCELLIERE TEDESCO", "DIO CANNIBALE"];
const welcomeMessage = bestemmie[Math.floor(Math.random() * bestemmie.length)];
        await Miku.sendMessage(m.from,        {
          video: { url: "https://media.tenor.com/W_zpI1dZXfwAAAPo/germano-mosconi.mp4" },
          caption: `*${welcomeMessage}*\n`,
          gifPlayback: true,
        },{quoted:m})
    }
}