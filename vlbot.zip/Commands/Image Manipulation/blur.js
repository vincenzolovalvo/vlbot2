const Jimp = require("jimp");

module.exports = {
  name: "blur",
  alias: ["imageblur"],
  desc: "To make a blurred image",
  category: "Image Manipulation",
  usage: "blur <reply to image>",
  react: "🍁",
  start: async (Miku, m, { text, prefix, quoted, pushName, mime, body }) => {
    if (!m.quoted && !/image/.test(mime))
      return m.reply("Tagga una foto !");

    if (/image/.test(mime)) {
      userPfp = await quoted.download();
    } else if (m.quoted) {
      try {
        userPfp = await Miku.profilePictureUrl(m.quoted.sender, "image");
      } catch (e) {
        return m.reply(
          "Il contatto selezionato non ha una foto profilo oppure la foto è privata!"
        );
      }
    } else {
      return m.reply("Tagga una foto !");
    }

    let level = text.split(" ")[1] || 5;
    const img = await Jimp.read(userPfp);
    img.blur(isNaN(level) ? 5 : parseInt(level));

    img.getBuffer(`image/png`, (err, buffer) => {
      if (!err) {
        Miku.sendMessage(
          m.from,
          { image: buffer, caption: `_Created by:_ *${botName}*` },
          { quoted: m }
        );
      } else {
        console.error(err);
        m.reply("An error occurd !");
      }
    });
  },
};
