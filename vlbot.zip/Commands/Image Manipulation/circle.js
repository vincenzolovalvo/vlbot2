const Canvacord = require("canvacord");

module.exports = {
  name: "imagecircle2",
  alias: ["circle2"],
  desc: "To make circle sized image",
  category: "Image Manipulation",
  usage: "circle <reply to image>",
  react: "🍁",
  start: async (Miku, m, { text, prefix, quoted, pushName, mime, body }) => {
    if (!m.quoted && !/image/.test(mime))
      return m.reply("Tagga una foto !");

    if (/image/.test(mime)) {
      userPfp = await quoted.download();
    } else if (m.quoted) {
      try {
        userPfp = await Miku.profilePictureUrl(m.quoted.sender, "image");
      } catch (e) {
        return m.reply(
          "Il contatto selezionato non ha una foto profilo oppure la foto è privata!"
        );
      }
    } else {
      return m.reply("Tagga una foto !");
    }

    const result = await Canvacord.Canvacord.circle(userPfp, false);

    await Miku.sendMessage(
      m.from,
      { image: result, caption: "Ecco qui...\n" },
      { quoted: m }
    );
  },
};
