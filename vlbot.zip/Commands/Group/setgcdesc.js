module.exports = {
  name: "setgcdesc",
  alias: ["setdescgc", "setdesc", "setgroupdesc", "setgroupdescription", "descrizione"],
  desc: "Change the group description",
  category: "Group",
  usage: `setdesc <New group description>`,
  react: "🍁",
  start: async (
    Miku,
    m,
    { text, prefix, isBotAdmin, isAdmin, pushName, metadata, args, mime }
  ) => {
    if (!isAdmin && !isBotAdmin) return m.reply(`Il bot e *${pushName}* Devono essere entrambi amministatori per eseguire il comando !`);
    if (!args[0])
      return Miku.sendMessage(
        m.from,
        { text: `Scrivi una nuova descrizione da sostituire a quella vecchia !` },
        { quoted: m }
      );

    var newGCdesc = args.join(" ");

    try {
      ppgc = await Miku.profilePictureUrl(m.from, "image");
    } catch {
      ppgc = botImage1;
    }

    await Miku.groupUpdateDescription(m.from, newGCdesc)
      .then((res) =>
        Miku.sendMessage(
          m.from,
          {
            image: { url: ppgc, mimetype: "image/jpeg" },
            caption: `*『 Nuova Descrizione Del Gruppo 』*\n\n_🧩 Nuova Descrizione:_\n*${args.join(
              " "
            )}*`,
          },
          { quoted: m }
        )
      )
      .catch((err) => replay(jsonformat(err)));
  },
};
