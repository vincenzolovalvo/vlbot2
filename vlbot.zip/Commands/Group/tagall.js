module.exports = {
  name: "tagall",
  alias: ["tag", "all"],
  desc: "Tag all group member",
  category: "Group",
  usage: "tagall",
  react: "🍁",
  start: async (
    Miku,
    m,
    { text, prefix, isBotAdmin, isAdmin, participants, args }
  ) => {
    

    let message = args
      ? args.join(" ")
      : m.quoted
      ? m.quoted.msg
      : "No Message";

    let mess = `               *『 ATTENZIONE 』*
    
*Tag da:* @${m.sender.split("@")[0]}
    
*Messaggio:* ${message}\n\n`;

    for (let mem of participants) {
      mess += `♢ @${mem.id.split("@")[0]}\n`;
    }
    mess += `\n\n                    *Grazie*\n`;

    await Miku.sendMessage(
      m.from,
      { text: mess, mentions: participants.map((a) => a.id) },
      { quoted: m }
    );
  },
};
