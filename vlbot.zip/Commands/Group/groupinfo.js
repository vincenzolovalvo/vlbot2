const moment = require('moment-timezone')

module.exports = {
    name: "gcinfo",
    alias: ["groupinfo", "infogruppo" ],
    desc: "Change the group description",
    category: "Group",
    usage: `setdesc <New group description>`,
    react: "🍁",
    start: async (
      Miku,
      m,
      { text, prefix, isBotAdmin, isAdmin, pushName, metadata, args,mime }
    ) => {
        try {
            ppgc = await Miku.profilePictureUrl(m.from, "image");
          } catch {
            ppgc = botImage1;
          }
          const participants = m.isGroup ? await metadata.participants : ''
          const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
          const groupOwner = m.isGroup ? metadata.owner : ''    
          desc = metadata.desc ? metadata.desc : 'Nessuna Descrizione'
          let txt = `                 *『 Info Del Gruppo 』*\n\n_🎀 Nome Gruppo:_ *${metadata.subject}*\n\n_🧩 Descrizione:_\n${desc}\n\n_👑 Creatore Del Gruppo:_ @${metadata.owner.split('@')[0]}\n_💫 Il Gruppo è stato creato il:_ *${moment(`${metadata.creation}` * 1000).tz('Asia/Kolkata').format('DD/MM/YYYY')}*\n_📛 Amministratori:_ *${groupAdmins.length}*\n_🎈 Numero partecipanti:_ *${metadata.participants.length}*\n`;
        
          await Miku.sendMessage(
            m.from,
        {
          image: { url: ppgc, mimetype: "image/jpeg" },
          caption: txt,
          mentions: [metadata.owner]
        },
        { quoted: m }
      );
    }
  }