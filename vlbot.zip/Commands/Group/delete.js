module.exports = {
  name: "delete",
  alias: ["del", "elimina"],
  desc: "To delete a message",
  category: "Group",
  usage: `Tag a message and type *del*`,
  react: "🍁",
  start: async (Miku, m, { isAdmin, isBotAdmin, pushName }) => {
    if (!m.quoted)
      return m.reply(`Rispondi ad un messaggio da eliminare !`);

    if (!isAdmin && !isBotAdmin) return m.reply(`Il bot e *${pushName}* Devono essere entrambi amministatori per eseguire il comando !`);
    
    var { from, fromMe, id } = m.quoted;

    const key = {
      remoteJid: m.from,
      fromMe: false,
      id: m.quoted.id,
      participant: m.quoted.sender,
    };

    await Miku.sendMessage(m.from, { delete: key });
  },
};
