module.exports = {
  name: "admins",
  alias: ["tagadmins", "admin"],
  desc: "Tag all group Admins.",
  category: "Group",
  usage: "admins <your message>",
  react: "🍁",
  start: async (
    Miku,
    m,
    { text, prefix, isAdmin, participants, args, groupAdmin }
  ) => {
    let message = "      『 *Attenzione Amministratori* 』";

    if (m.quoted) {
      message = "     『 *Attenzione Amministratori* 』";
    } else if (!text && m.quoted) {
      message = `${m.quoted ? m.quoted.msg : ""}`;
    } else if (args[0]) {
      message = `     『 *Attenzione Amministratori* 』\n\n_🎀 Message:_ *${args.join(
        " "
      )}*`;
    } else if (text === "") {
      message = "     『 *Attenzione Amministratori* 』";
    } else {
      message = "     『 *Attenzione Amministratori* 』";
    }

    Miku.sendMessage(
      m.from,
      { text: message, mentions: groupAdmin },
      { quoted: m }
    );
  },
};
