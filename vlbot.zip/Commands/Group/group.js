module.exports = {
  name: "group",
  alias: ["gc"],
  desc: "Open / Close Group",
  category: "Group",
  usage: `group open/close`,
  react: "🍁",
  start: async (
    Miku,
    m,
    {
      text,
      prefix,
      isBotAdmin,
      isAdmin,
      args,
      pushName,
    }
  ) => {
    if (!isAdmin && !isBotAdmin) return m.reply(`Il bot e *${pushName}* Devono essere entrambi amministatori per eseguire il comando !`);
    
    if (args[0] === "close") {
      await Miku.groupSettingUpdate(m.from, "announcement").then((res) =>
        m.reply(`Il Gruppo è stato chiuso!`)
      );
    } else if (args[0] === "open") {
      await Miku.groupSettingUpdate(m.from, "not_announcement").then((res) =>
        m.reply(`Il gruppo è stato aperto!`)
      );
    } else {
      
      await Miku.sendMessage(m.from, {image: { url: botImage2}, caption: `\n*「 Impostazione dei Messaggi 」*\n\nSelezionare un opzione sottostante.\n\n*_Uso:_*\n\n*${prefix}group open*\n*${prefix}group close*\n`,}, { quoted: m });
    }
  },
};
