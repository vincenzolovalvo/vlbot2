const { mk } = require("../../Database/dataschema.js");

module.exports = {
  name: "welcome",
  alias: ["welcomemess", "welcomeswitch", "benvenuto"],
  desc: "Enable or disable Welcome/Goodbye messages in a group",
  category: "Group",
  usage: "welcome [on/off]",
  react: "🎀",
  start: async (
    Miku,
    m,
    { args, isBotAdmin, isAdmin, isCreator, reply, prefix, pushName }
  ) => {
    if (!isAdmin)
      return m.reply(mess.useradmin)

    let checkdata = await mk.findOne({ id: m.from });
    var groupe = await Miku.groupMetadata(m.from);
    var members = groupe["participants"];
    var mems = [];
    members.map(async (adm) => {
      mems.push(adm.id.replace("c.us", "s.whatsapp.net"));
    });

    if (args[0] === "on") {
      if (!checkdata) {
        await new mk({ id: m.from, switchWelcome: "true" }).save();
        Miku.sendMessage(
          m.from,
          {
            text: `*Benvenuto/Arrivederci* sono stati *Attivati* in questo gruppo!`,
            contextInfo: { mentionedJid: mems },
          },
          { quoted: m }
        );
        return Miku.sendMessage(
          m.from,
          {
            text: `*Benvenuto/Arrivederci* sono stati *Attivati* in questo gruppo!`,
          },
          { quoted: m }
        );
      } else {
        if (checkdata.switchWelcome == "true")
          return Miku.sendMessage(
            m.from,
            {
              text: `*Benvenuto/Arrivederci* sono stati *Attivati* in questo gruppo!`,
            },
            { quoted: m }
          );
        await mk.updateOne({ id: m.from }, { switchWelcome: "true" });
        return Miku.sendMessage(
          m.from,
          {
            text: `*Benvenuto/Arrivederci* sono stati *Attivati* in questo gruppo`,
          },
          { quoted: m }
        );
      }
    } else if (args[0] === "off") {
      if (!checkdata) {
        await new mk({ id: m.from, switchWelcome: "false" }).save();
        return Miku.sendMessage(
          m.from,
          {
            text: `*Benvenuto/Arrivederci* sono stati *disattivati* in questo gruppo`,
          },
          { quoted: m }
        );
      } else {
        if (checkdata.switchWelcome == "false")
          return Miku.sendMessage(
            m.from,
            { text: `*Benvenuto/Arrivederci* sono *disattivati* in questo gruppo!` },
            { quoted: m }
          );
        await mk.updateOne({ id: m.from }, { switchWelcome: "false" });
        return Miku.sendMessage(
          m.from,
          {
            text: `*Benvenuto/Arrivederci* sono stati *disattivati* in questo gruppo!`,
          },
          { quoted: m }
        );
      }
    } else {
      
      await Miku.sendMessage(m.from, {image: { url: botImage2 },caption: `\n*「 Benvenuto/Arrivederci 」*\n\nNote: *Benvenuto/Arrivederci* Sono mandati quando qualcuno entra o esce dal gruppo.\n\n*_Uso:_* \n\n${prefix}benvenuto on\n${prefix}benvenuto off\n\n*Sato attuale:* ${checkdata.switchWelcome == "true" ? "On" : "Off"}`,}, { quoted: m });
    }
  },
};
