module.exports = {
  name: "demote",
  alias: ["dem"],
  desc: "Demote a member",
  category: "Group",
  usage: "demote @user",
  react: "🍁",
  start: async (
    Miku,
    m,
    { text, prefix, isBotAdmin, isAdmin, mentionByTag, pushName, groupAdmin }
  ) => {
    if (!isAdmin && !isBotAdmin) return m.reply(`Il bot e *${pushName}* Devono essere entrambi amministatori per eseguire il comando !`);

    if (!text && !m.quoted) {
      return Miku.sendMessage(
        m.from,
        { text: `Tagga un utente per eseguire *Demote*!` },
        { quoted: m }
      );
    } else if (m.quoted) {
      var mentionedUser = m.quoted.sender;
    } else {
      var mentionedUser = mentionByTag[0];
    }

    let userId = (await mentionedUser) || m.msg.contextInfo.participant;
    if (!groupAdmin.includes(userId)) {
      return Miku.sendMessage(
        m.from,
        {
          text: `@${mentionedUser.split("@")[0]} la persona taggata non è un *Admin* !`,
          mentions: [mentionedUser],
        },
        { quoted: m }
      );
    }

    try {
      await Miku.groupParticipantsUpdate(m.from, [userId], "demote").then(
        (res) =>
          Miku.sendMessage(
            m.from,
            {
              text: `Sorry @${
                mentionedUser.split("@")[0]
              } Sei stato rimosso da admin da *${pushName}* !`,
              mentions: [mentionedUser],
            },
            { quoted: m }
          )
      );
    } catch (error) {
      Miku.sendMessage(m.from, { text: `${mess.botadmin}` }, { quoted: m });
    }
  },
};
