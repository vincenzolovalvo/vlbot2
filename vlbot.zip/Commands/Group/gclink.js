require("../../config.js");
require("../../Core.js");

module.exports = {
  name: "grouplink",
  alias: ["gclink", "linkgruppo"],
  desc: "To get concurrent group link.",
  category: "Group",
  usage: "gclink",
  react: "🍁",
  start: async (Miku, m, { prefix, isBotAdmin, isAdmin, metadata, mime }) => {

    if (!isBotAdmin) return m.reply(mess.botadmin);

    var link = await Miku.groupInviteCode(m.from);
    var linkcode = `https://chat.whatsapp.com/${link}`;

    try {
      ppgc = await Miku.profilePictureUrl(m.from, "image");
    } catch {
      ppgc = botImage1;
    }

    try {
      await Miku.sendMessage(
        m.from,
        {
          image: { url: ppgc, mimetype: "image/jpeg" },
          caption: `\n_🎀 Nome Gruppo:_ *${metadata.subject}*\n\n_🔷 Link Gruppo:_\n${linkcode}\n`,
        },
        { quoted: m }
      );
    } catch (err) {
      Miku.sendMessage(m.from, { text: `${mess.botadmin}` }, { quoted: m });
    }
  },
};
