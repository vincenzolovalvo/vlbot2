const { serialize } = require("./system");

module.exports = {
    Collection: require("./collections.js"),
     Simple: require("./system"),
    
};